import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import  * as $ from   'jquery';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'homepage';
  show=false;
  constructor(private  router:Router )
  {
    this.show=false;
  }
  
  ngOnInit(){
    ($('#myCarousel')as any).carousel({
      interval: 2000,
      cycle: true
    })
  }
    gotoPage(url: string){
   
  
  }
  remove()
  {
    this.show=false;
  }
  add(){ 
    this.show=true;
    
  
  } 
}
