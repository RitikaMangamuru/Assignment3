import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Sst1Component } from './sst1.component';

describe('Sst1Component', () => {
  let component: Sst1Component;
  let fixture: ComponentFixture<Sst1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Sst1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Sst1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
