import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sst1',
  templateUrl: './sst1.component.html',
  styleUrls: ['./sst1.component.css']
})
export class Sst1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
