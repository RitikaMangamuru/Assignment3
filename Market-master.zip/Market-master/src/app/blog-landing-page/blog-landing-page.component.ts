import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-landing-page',
  templateUrl: './blog-landing-page.component.html',
  styleUrls: ['./blog-landing-page.component.css']
})
export class BlogLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
