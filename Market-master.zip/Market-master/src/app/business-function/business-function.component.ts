import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-function',
  templateUrl: './business-function.component.html',
  styleUrls: ['./business-function.component.css']
})
export class BusinessFunctionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
