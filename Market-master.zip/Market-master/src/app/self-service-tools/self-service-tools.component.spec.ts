import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelfServiceToolsComponent } from './self-service-tools.component';

describe('SelfServiceToolsComponent', () => {
  let component: SelfServiceToolsComponent;
  let fixture: ComponentFixture<SelfServiceToolsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SelfServiceToolsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SelfServiceToolsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
