import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-self-service-tools',
  templateUrl: './self-service-tools.component.html',
  styleUrls: ['./self-service-tools.component.css']
})
export class SelfServiceToolsComponent implements OnInit {

  constructor() { }
  
  ngOnInit(): void {
  }

}
