import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-blog-editor',
  templateUrl: './blog-editor.component.html',
  styleUrls: ['./blog-editor.component.css']
})
export class BlogEditorComponent implements OnInit {

  formdata;
  url:any
  constructor(private formBuilder: FormBuilder) { }
  onClickSubmit(data) {
      if(this.formdata.invalid)
     {
      
    this.formdata.get('description').markAsTouched();
    
    }
  }
  onSelectFile(event) { 
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
 
      reader.readAsDataURL(event.target.files[0]); 
 
      reader.onload = (event) => { 
        this.url = event.target.result;
      }
    }
}
 
  ngOnInit(): void {
 
    this.formdata = this.formBuilder.group({
      description: ['', [Validators.required,
        Validators.maxLength(400), Validators.minLength(5)]]
  })
  ;
  
}
 

}
