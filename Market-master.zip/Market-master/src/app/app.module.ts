import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { IvyCarouselModule } from 'angular-responsive-carousel'
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppComponent } from './app.component';
import { CardComponent } from './card/card.component';
import { CarouselComponent } from './carousel/carousel.component';
import { NavbarComponent } from './navbar/navbar.component';
import { JumbotronComponent } from './jumbotron/jumbotron.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MatTabsModule } from '@angular/material/tabs';
import { SelfServiceToolsComponent } from './self-service-tools/self-service-tools.component';
import { HomeComponent } from './home/home.component';
import { Routes,RouterModule } from '@angular/router';
import { UniversalSearchComponent } from './universal-search/universal-search.component';
import { Sst1Component } from './sst1/sst1.component';
import { BusinessFunctionComponent } from './business-function/business-function.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { ResourceComponent } from './resource/resource.component';
import { ArticleComponent } from './article/article.component';
import { BlogLandingPageComponent } from './blog-landing-page/blog-landing-page.component';
import { BlogArticleComponent } from './blog-article/blog-article.component';
import { BlogEditorComponent } from './blog-editor/blog-editor.component';
import {FormsModule}   from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { HttpClientModule, HttpClient } from '@angular/common/http';




const appRoutes: Routes=[
  {path:'',component:HomeComponent},
  {path:'Service',component:SelfServiceToolsComponent },
  {path:'universal',component:UniversalSearchComponent },
  {path:'sst1',component:Sst1Component },
  {path:'Business',component:BusinessFunctionComponent },
  {path:'Technologies',component:TechnologiesComponent },
  {path:'Resource',component:ResourceComponent },
  {path:'article',component:ArticleComponent },
  {path:'Community',component:BlogLandingPageComponent},
  {path:'blogdes',component:BlogArticleComponent},
  {path:'newpost',component:BlogEditorComponent}


];

@NgModule({
  declarations: [
    AppComponent,
    CardComponent,
    CarouselComponent ,
    NavbarComponent,
    JumbotronComponent,
    FooterComponent,
    HeaderComponent,
    SelfServiceToolsComponent,
    HomeComponent,
    UniversalSearchComponent,
    Sst1Component,
    BusinessFunctionComponent,
    TechnologiesComponent,
    ResourceComponent,
    ArticleComponent,
    BlogLandingPageComponent,
    BlogArticleComponent,
    BlogEditorComponent
    
  ],
  exports: [RouterModule],
  imports: [
    BrowserModule,
    MatTabsModule,
    IvyCarouselModule,
    NgbModule,
    NoopAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    AngularEditorModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
   
  ],
  providers: [],
  bootstrap: [AppComponent,BlogLandingPageComponent,CardComponent,SelfServiceToolsComponent,CarouselComponent,FooterComponent,HomeComponent]
})
export class AppModule { 
   
}
