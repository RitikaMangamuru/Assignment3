import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-universal-search',
  templateUrl: './universal-search.component.html',
  styleUrls: ['./universal-search.component.css']
})
export class UniversalSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
